--
-- PostgreSQL database dump
--

\restrict Q2H99zOmWBFKsh19AMuwiph4ehEhGrmXkAYTG3c2z7t5ea9fGgPqZ75ZbgRcT6o

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: benutzer_rolle; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.benutzer_rolle AS ENUM (
    'admin',
    'lehrer',
    'mitarbeiter'
);


ALTER TYPE public.benutzer_rolle OWNER TO postgres;

--
-- Name: set_aktualisiert_am(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_aktualisiert_am() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.aktualisiert_am = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_aktualisiert_am() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tabelle character varying(50) NOT NULL,
    aktion character varying(20) NOT NULL,
    datensatz_id uuid NOT NULL,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    bearbeiter_id uuid,
    details jsonb,
    akteur character varying(10) DEFAULT 'USER'::character varying NOT NULL,
    kontext text,
    CONSTRAINT audit_log_akteur_check CHECK (((akteur)::text = ANY ((ARRAY['USER'::character varying, 'SYSTEM'::character varying])::text[])))
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- Name: ausleihen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ausleihen (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    exemplar_id uuid NOT NULL,
    schueler_id uuid,
    ausleiher_benutzer_id uuid,
    ausgeliehen_am timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    rueckgabe_frist timestamp with time zone NOT NULL,
    rueckgabe_am timestamp with time zone,
    bearbeiter_id uuid,
    rueckgabe_bearbeiter_id uuid,
    ist_fremdrueckgabe boolean DEFAULT false NOT NULL,
    ist_handapparat boolean DEFAULT false NOT NULL,
    CONSTRAINT check_loan_borrower CHECK ((((schueler_id IS NOT NULL) AND (ausleiher_benutzer_id IS NULL)) OR ((schueler_id IS NULL) AND (ausleiher_benutzer_id IS NOT NULL)) OR ((schueler_id IS NULL) AND (ausleiher_benutzer_id IS NULL)))),
    CONSTRAINT check_return_date CHECK (((rueckgabe_am IS NULL) OR (rueckgabe_am >= ausgeliehen_am)))
);


ALTER TABLE public.ausleihen OWNER TO postgres;

--
-- Name: benutzer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.benutzer (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    barcode_id character varying(100),
    vorname character varying(100) NOT NULL,
    nachname character varying(100) NOT NULL,
    email character varying(255) NOT NULL,
    passwort_hash character varying(255) NOT NULL,
    rolle public.benutzer_rolle NOT NULL,
    aktiv boolean DEFAULT true NOT NULL,
    erstellt_am timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    aktualisiert_am timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.benutzer OWNER TO postgres;

--
-- Name: benutzer_rollen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.benutzer_rollen (
    benutzer_id uuid NOT NULL,
    rolle character varying(50) NOT NULL,
    CONSTRAINT benutzer_rollen_rolle_check CHECK (((rolle)::text = ANY ((ARRAY['ADMIN'::character varying, 'MITARBEITER'::character varying, 'LEHRER'::character varying, 'HELFER'::character varying])::text[])))
);


ALTER TABLE public.benutzer_rollen OWNER TO postgres;

--
-- Name: buecher_exemplare; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.buecher_exemplare (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    titel_id uuid NOT NULL,
    barcode_id character varying(100) NOT NULL,
    zustand_notiz text,
    erworben_am date DEFAULT CURRENT_DATE NOT NULL,
    ist_ausleihbar boolean DEFAULT true NOT NULL,
    inventur_geprueft_am timestamp with time zone,
    erweiterte_eigenschaften jsonb DEFAULT '{}'::jsonb NOT NULL,
    erstellt_am timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    aktualisiert_am timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ist_ausgesondert boolean DEFAULT false NOT NULL
);


ALTER TABLE public.buecher_exemplare OWNER TO postgres;

--
-- Name: buecher_titel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.buecher_titel (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    titel character varying(255) NOT NULL,
    untertitel character varying(255),
    autor character varying(255),
    isbn character varying(20),
    verlag character varying(255),
    erscheinungsjahr integer,
    beschreibung text,
    meldebestand integer DEFAULT 5 NOT NULL,
    cover_url character varying(512),
    subject character varying(100),
    grade_level smallint,
    track character varying(100),
    stock integer DEFAULT 0 NOT NULL,
    last_counted date,
    sort_order integer NOT NULL,
    medientyp character varying(100) DEFAULT 'Buch'::character varying NOT NULL,
    erweiterte_eigenschaften jsonb DEFAULT '{}'::jsonb NOT NULL,
    erstellt_am timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    aktualisiert_am timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    search_vector tsvector GENERATED ALWAYS AS (to_tsvector('german'::regconfig, (((((((COALESCE(titel, ''::character varying))::text || ' '::text) || (COALESCE(untertitel, ''::character varying))::text) || ' '::text) || (COALESCE(autor, ''::character varying))::text) || ' '::text) || (COALESCE(verlag, ''::character varying))::text))) STORED
);


ALTER TABLE public.buecher_titel OWNER TO postgres;

--
-- Name: buecher_titel_sort_order_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.buecher_titel_sort_order_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.buecher_titel_sort_order_seq OWNER TO postgres;

--
-- Name: buecher_titel_sort_order_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.buecher_titel_sort_order_seq OWNED BY public.buecher_titel.sort_order;


--
-- Name: class_books; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.class_books (
    class_name character varying(50) NOT NULL,
    book_id uuid NOT NULL
);


ALTER TABLE public.class_books OWNER TO postgres;

--
-- Name: klassen_lehrer_mapping; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.klassen_lehrer_mapping (
    klasse character varying(50) NOT NULL,
    lehrer_email character varying(255) NOT NULL,
    erstellt_am timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.klassen_lehrer_mapping OWNER TO postgres;

--
-- Name: klassensatz_reservierungen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.klassensatz_reservierungen (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    titel_id uuid NOT NULL,
    klasse character varying(50) NOT NULL,
    anzahl integer DEFAULT 1 NOT NULL,
    notiz text,
    angefordert_von uuid,
    erledigt boolean DEFAULT false NOT NULL,
    erstellt_am timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.klassensatz_reservierungen OWNER TO postgres;

--
-- Name: lieferanten; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lieferanten (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    kundennummer character varying(100) NOT NULL,
    erstellt_am timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.lieferanten OWNER TO postgres;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.role_permissions (
    role character varying(50) NOT NULL,
    permission character varying(100) NOT NULL,
    allowed boolean DEFAULT false NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO postgres;

--
-- Name: schadensfaelle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schadensfaelle (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    exemplar_id uuid NOT NULL,
    ausleihe_id uuid,
    schueler_id uuid,
    benutzer_id uuid,
    beschreibung text NOT NULL,
    betrag numeric(10,2) DEFAULT 0.00 NOT NULL,
    ist_bezahlt boolean DEFAULT false NOT NULL,
    elternbrief_generiert boolean DEFAULT false NOT NULL,
    elternbrief_generiert_am timestamp with time zone,
    erstellt_am timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    aktualisiert_am timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    storniert_am timestamp with time zone,
    storniert_von uuid,
    stornierungsgrund text,
    CONSTRAINT check_damage_responsible CHECK ((((schueler_id IS NOT NULL) AND (benutzer_id IS NULL)) OR ((schueler_id IS NULL) AND (benutzer_id IS NOT NULL)) OR ((schueler_id IS NULL) AND (benutzer_id IS NULL)))),
    CONSTRAINT check_positive_amount CHECK ((betrag >= 0.00))
);


ALTER TABLE public.schadensfaelle OWNER TO postgres;

--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schema_migrations (
    version character varying(255) NOT NULL,
    applied_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO postgres;

--
-- Name: schueler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.schueler (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    barcode_id character varying(100) NOT NULL,
    vorname character varying(100) NOT NULL,
    nachname character varying(100) NOT NULL,
    klasse character varying(20) NOT NULL,
    geburtsdatum date,
    abgaenger_jahr integer NOT NULL,
    ist_gesperrt boolean DEFAULT false NOT NULL,
    lusd_id character varying(64),
    ist_abgaenger boolean DEFAULT false NOT NULL,
    erstellt_am timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    aktualisiert_am timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.schueler OWNER TO postgres;

--
-- Name: subjects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subjects (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.subjects OWNER TO postgres;

--
-- Name: subjects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.subjects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.subjects_id_seq OWNER TO postgres;

--
-- Name: subjects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.subjects_id_seq OWNED BY public.subjects.id;


--
-- Name: system_einstellungen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_einstellungen (
    schluessel character varying(100) NOT NULL,
    wert text,
    aktualisiert_am timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.system_einstellungen OWNER TO postgres;

--
-- Name: vormerkungen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vormerkungen (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    titel_id uuid NOT NULL,
    schueler_id uuid,
    notiz text,
    erstellt_am timestamp with time zone DEFAULT now() NOT NULL,
    benachrichtigt_am timestamp with time zone
);


ALTER TABLE public.vormerkungen OWNER TO postgres;

--
-- Name: buecher_titel sort_order; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buecher_titel ALTER COLUMN sort_order SET DEFAULT nextval('public.buecher_titel_sort_order_seq'::regclass);


--
-- Name: subjects id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects ALTER COLUMN id SET DEFAULT nextval('public.subjects_id_seq'::regclass);


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (id, tabelle, aktion, datensatz_id, "timestamp", bearbeiter_id, details, akteur, kontext) FROM stdin;
\.


--
-- Data for Name: ausleihen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ausleihen (id, exemplar_id, schueler_id, ausleiher_benutzer_id, ausgeliehen_am, rueckgabe_frist, rueckgabe_am, bearbeiter_id, rueckgabe_bearbeiter_id, ist_fremdrueckgabe, ist_handapparat) FROM stdin;
\.


--
-- Data for Name: benutzer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.benutzer (id, barcode_id, vorname, nachname, email, passwort_hash, rolle, aktiv, erstellt_am, aktualisiert_am) FROM stdin;
00000000-0000-0000-0000-000000000001	admin	System	Administrator	admin@bibliothek.local	$2a$10$S3ZxkHD9TPmJkmemFei2teE/IPDwYebnTPWJx0dOsjUxzP9Plf3ky	admin	t	2026-05-31 06:26:19.908514+00	2026-05-31 06:26:19.908514+00
00000000-0000-0000-0000-000000000002	L-999	Maria	Müller	m.mueller@schule.de	$2a$10$TL2D3tEjq72DYIBje3wiUOCWOgqiJ3OgqbGboZKWKj2a0mc7do0wK	lehrer	t	2026-05-31 06:26:19.908801+00	2026-05-31 06:26:19.908801+00
\.


--
-- Data for Name: benutzer_rollen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.benutzer_rollen (benutzer_id, rolle) FROM stdin;
00000000-0000-0000-0000-000000000001	ADMIN
00000000-0000-0000-0000-000000000002	LEHRER
\.


--
-- Data for Name: buecher_exemplare; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.buecher_exemplare (id, titel_id, barcode_id, zustand_notiz, erworben_am, ist_ausleihbar, inventur_geprueft_am, erweiterte_eigenschaften, erstellt_am, aktualisiert_am, ist_ausgesondert) FROM stdin;
00000000-0000-0000-0000-000000000005	00000000-0000-0000-0000-000000000004	B-200	\N	2026-05-31	t	\N	{}	2026-05-31 06:26:19.910432+00	2026-05-31 06:26:19.910432+00	f
\.


--
-- Data for Name: buecher_titel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.buecher_titel (id, titel, untertitel, autor, isbn, verlag, erscheinungsjahr, beschreibung, meldebestand, cover_url, subject, grade_level, track, stock, last_counted, sort_order, medientyp, erweiterte_eigenschaften, erstellt_am, aktualisiert_am) FROM stdin;
00000000-0000-0000-0000-000000000004	LMF-Mathematik 10	Gymnasium Bayern	Dr. Arndt	9783127337001	Klett	2022	\N	5	\N	\N	\N	\N	0	\N	1	Buch	{}	2026-05-31 06:26:19.909521+00	2026-05-31 06:26:19.909521+00
\.


--
-- Data for Name: class_books; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.class_books (class_name, book_id) FROM stdin;
\.


--
-- Data for Name: klassen_lehrer_mapping; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.klassen_lehrer_mapping (klasse, lehrer_email, erstellt_am) FROM stdin;
\.


--
-- Data for Name: klassensatz_reservierungen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.klassensatz_reservierungen (id, titel_id, klasse, anzahl, notiz, angefordert_von, erledigt, erstellt_am) FROM stdin;
\.


--
-- Data for Name: lieferanten; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lieferanten (id, name, email, kundennummer, erstellt_am) FROM stdin;
23a03d96-9d76-45ff-9399-1914adffc206	Klett Verlag	bestellung@klett.de	K-99281	2026-05-31 06:26:25.015801+00
57e36de4-9f60-45a1-bc42-a8cafc4ef09c	Cornelsen	service@cornelsen.de	C-88123	2026-05-31 06:26:25.016046+00
23a5f90b-09d0-4c56-bf3b-d06e48124350	Westermann	order@westermann.de	W-77441	2026-05-31 06:26:25.016213+00
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.role_permissions (role, permission, allowed) FROM stdin;
ADMIN	view_students	t
ADMIN	create_students	t
ADMIN	delete_students	t
ADMIN	import_students	t
ADMIN	upload_photos	t
ADMIN	view_books	t
ADMIN	edit_books	t
ADMIN	delete_books	t
ADMIN	inventory_scan	t
ADMIN	view_orders	t
ADMIN	create_orders	t
ADMIN	view_graduates	t
ADMIN	view_stats	t
ADMIN	audit_logs	t
ADMIN	manage_users	t
MITARBEITER	view_students	t
MITARBEITER	create_students	t
MITARBEITER	delete_students	t
MITARBEITER	import_students	t
MITARBEITER	upload_photos	t
MITARBEITER	view_books	t
MITARBEITER	edit_books	t
MITARBEITER	delete_books	t
MITARBEITER	inventory_scan	t
MITARBEITER	view_orders	t
MITARBEITER	create_orders	t
MITARBEITER	view_graduates	t
MITARBEITER	view_stats	t
MITARBEITER	audit_logs	f
MITARBEITER	manage_users	f
LEHRER	view_students	t
LEHRER	create_students	f
LEHRER	delete_students	f
LEHRER	import_students	f
LEHRER	upload_photos	t
LEHRER	view_books	t
LEHRER	edit_books	f
LEHRER	delete_books	f
LEHRER	inventory_scan	f
LEHRER	view_orders	f
LEHRER	create_orders	f
LEHRER	view_graduates	f
LEHRER	view_stats	f
LEHRER	audit_logs	f
LEHRER	manage_users	f
HELFER	view_students	f
HELFER	create_students	f
HELFER	delete_students	f
HELFER	import_students	f
HELFER	upload_photos	f
HELFER	view_books	f
HELFER	edit_books	f
HELFER	delete_books	f
HELFER	inventory_scan	f
HELFER	view_orders	f
HELFER	create_orders	f
HELFER	view_graduates	f
HELFER	view_stats	f
HELFER	audit_logs	f
HELFER	manage_users	f
\.


--
-- Data for Name: schadensfaelle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schadensfaelle (id, exemplar_id, ausleihe_id, schueler_id, benutzer_id, beschreibung, betrag, ist_bezahlt, elternbrief_generiert, elternbrief_generiert_am, erstellt_am, aktualisiert_am, storniert_am, storniert_von, stornierungsgrund) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schema_migrations (version, applied_at) FROM stdin;
001_initial_baseline.sql	2026-06-01 06:47:04.803757+00
002_dsgvo_audit_hardening.sql	2026-06-01 06:47:04.804293+00
003_dsgvo_lusd_datensparsamkeit.sql	2026-06-01 06:47:04.812408+00
004_aussonderung.sql	2026-06-01 06:47:04.822128+00
\.


--
-- Data for Name: schueler; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.schueler (id, barcode_id, vorname, nachname, klasse, geburtsdatum, abgaenger_jahr, ist_gesperrt, lusd_id, ist_abgaenger, erstellt_am, aktualisiert_am) FROM stdin;
00000000-0000-0000-0000-000000000003	S-100	Max	Mustermann	10b	\N	2028	f	\N	f	2026-05-31 06:26:19.90922+00	2026-05-31 06:26:19.90922+00
\.


--
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subjects (id, name, is_active) FROM stdin;
1	Deutsch	t
2	Englisch	t
3	Mathematik	t
4	Physik	t
5	Chemie	t
6	Biologie	t
7	Geschichte	t
8	Geographie	t
9	Politik	t
10	Informatik	t
11	Kunst	t
12	Musik	t
13	Religion	t
14	Latein	t
15	Französisch	t
16	Naturwissenschaften	t
\.


--
-- Data for Name: system_einstellungen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_einstellungen (schluessel, wert, aktualisiert_am) FROM stdin;
ferien_leseclub_aktiv	false	2026-05-31 06:26:19.901613+00
ferien_leseclub_zieldatum	\N	2026-05-31 06:26:19.901613+00
lmf_stichtag	07-31	2026-05-31 06:26:19.901613+00
max_ausleihen_schueler	5	2026-05-31 06:26:19.901613+00
\.


--
-- Data for Name: vormerkungen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vormerkungen (id, titel_id, schueler_id, notiz, erstellt_am, benachrichtigt_am) FROM stdin;
\.


--
-- Name: buecher_titel_sort_order_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.buecher_titel_sort_order_seq', 1, true);


--
-- Name: subjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subjects_id_seq', 16, true);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: ausleihen ausleihen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ausleihen
    ADD CONSTRAINT ausleihen_pkey PRIMARY KEY (id);


--
-- Name: benutzer benutzer_barcode_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.benutzer
    ADD CONSTRAINT benutzer_barcode_id_key UNIQUE (barcode_id);


--
-- Name: benutzer benutzer_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.benutzer
    ADD CONSTRAINT benutzer_email_key UNIQUE (email);


--
-- Name: benutzer benutzer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.benutzer
    ADD CONSTRAINT benutzer_pkey PRIMARY KEY (id);


--
-- Name: benutzer_rollen benutzer_rollen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.benutzer_rollen
    ADD CONSTRAINT benutzer_rollen_pkey PRIMARY KEY (benutzer_id);


--
-- Name: buecher_exemplare buecher_exemplare_barcode_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buecher_exemplare
    ADD CONSTRAINT buecher_exemplare_barcode_id_key UNIQUE (barcode_id);


--
-- Name: buecher_exemplare buecher_exemplare_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buecher_exemplare
    ADD CONSTRAINT buecher_exemplare_pkey PRIMARY KEY (id);


--
-- Name: buecher_titel buecher_titel_isbn_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buecher_titel
    ADD CONSTRAINT buecher_titel_isbn_key UNIQUE (isbn);


--
-- Name: buecher_titel buecher_titel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buecher_titel
    ADD CONSTRAINT buecher_titel_pkey PRIMARY KEY (id);


--
-- Name: class_books class_books_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_books
    ADD CONSTRAINT class_books_pkey PRIMARY KEY (class_name, book_id);


--
-- Name: klassen_lehrer_mapping klassen_lehrer_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.klassen_lehrer_mapping
    ADD CONSTRAINT klassen_lehrer_mapping_pkey PRIMARY KEY (klasse);


--
-- Name: klassensatz_reservierungen klassensatz_reservierungen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.klassensatz_reservierungen
    ADD CONSTRAINT klassensatz_reservierungen_pkey PRIMARY KEY (id);


--
-- Name: lieferanten lieferanten_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lieferanten
    ADD CONSTRAINT lieferanten_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role, permission);


--
-- Name: schadensfaelle schadensfaelle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schadensfaelle
    ADD CONSTRAINT schadensfaelle_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: schueler schueler_barcode_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schueler
    ADD CONSTRAINT schueler_barcode_id_key UNIQUE (barcode_id);


--
-- Name: schueler schueler_lusd_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schueler
    ADD CONSTRAINT schueler_lusd_id_key UNIQUE (lusd_id);


--
-- Name: schueler schueler_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schueler
    ADD CONSTRAINT schueler_pkey PRIMARY KEY (id);


--
-- Name: subjects subjects_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_name_key UNIQUE (name);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: system_einstellungen system_einstellungen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_einstellungen
    ADD CONSTRAINT system_einstellungen_pkey PRIMARY KEY (schluessel);


--
-- Name: vormerkungen vormerkungen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vormerkungen
    ADD CONSTRAINT vormerkungen_pkey PRIMARY KEY (id);


--
-- Name: idx_audit_log_tabelle_aktion; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_log_tabelle_aktion ON public.audit_log USING btree (tabelle, aktion, "timestamp" DESC);


--
-- Name: idx_ausleihen_aktive; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ausleihen_aktive ON public.ausleihen USING btree (rueckgabe_am) WHERE (rueckgabe_am IS NULL);


--
-- Name: idx_ausleihen_benutzer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ausleihen_benutzer ON public.ausleihen USING btree (ausleiher_benutzer_id) WHERE (ausleiher_benutzer_id IS NOT NULL);


--
-- Name: idx_ausleihen_exemplar; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ausleihen_exemplar ON public.ausleihen USING btree (exemplar_id);


--
-- Name: idx_ausleihen_rueckgabe_frist; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ausleihen_rueckgabe_frist ON public.ausleihen USING btree (rueckgabe_frist);


--
-- Name: idx_ausleihen_schueler; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ausleihen_schueler ON public.ausleihen USING btree (schueler_id) WHERE (schueler_id IS NOT NULL);


--
-- Name: idx_benutzer_barcode; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_benutzer_barcode ON public.benutzer USING btree (barcode_id) WHERE (barcode_id IS NOT NULL);


--
-- Name: idx_buecher_autor_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_buecher_autor_trgm ON public.buecher_titel USING gin (autor public.gin_trgm_ops);


--
-- Name: idx_buecher_exemplare_ausgesondert; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_buecher_exemplare_ausgesondert ON public.buecher_exemplare USING btree (ist_ausgesondert) WHERE (ist_ausgesondert = true);


--
-- Name: idx_buecher_exemplare_barcode; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_buecher_exemplare_barcode ON public.buecher_exemplare USING btree (barcode_id);


--
-- Name: idx_buecher_exemplare_titel; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_buecher_exemplare_titel ON public.buecher_exemplare USING btree (titel_id);


--
-- Name: idx_buecher_isbn_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_buecher_isbn_trgm ON public.buecher_titel USING gin (isbn public.gin_trgm_ops);


--
-- Name: idx_buecher_titel_search; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_buecher_titel_search ON public.buecher_titel USING gin (search_vector);


--
-- Name: idx_buecher_titel_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_buecher_titel_trgm ON public.buecher_titel USING gin (titel public.gin_trgm_ops);


--
-- Name: idx_schadensfaelle_benutzer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_schadensfaelle_benutzer ON public.schadensfaelle USING btree (benutzer_id) WHERE (benutzer_id IS NOT NULL);


--
-- Name: idx_schadensfaelle_exemplar; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_schadensfaelle_exemplar ON public.schadensfaelle USING btree (exemplar_id);


--
-- Name: idx_schadensfaelle_offene; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_schadensfaelle_offene ON public.schadensfaelle USING btree (ist_bezahlt) WHERE (ist_bezahlt = false);


--
-- Name: idx_schadensfaelle_schueler; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_schadensfaelle_schueler ON public.schadensfaelle USING btree (schueler_id) WHERE (schueler_id IS NOT NULL);


--
-- Name: idx_schueler_abgaenger_dsgvo; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_schueler_abgaenger_dsgvo ON public.schueler USING btree (abgaenger_jahr, ist_abgaenger) WHERE (ist_abgaenger = true);


--
-- Name: idx_schueler_barcode; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_schueler_barcode ON public.schueler USING btree (barcode_id);


--
-- Name: idx_schueler_nachname_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_schueler_nachname_trgm ON public.schueler USING gin (nachname public.gin_trgm_ops);


--
-- Name: idx_schueler_vorname_trgm; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_schueler_vorname_trgm ON public.schueler USING gin (vorname public.gin_trgm_ops);


--
-- Name: idx_vormerkungen_titel_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_vormerkungen_titel_id ON public.vormerkungen USING btree (titel_id);


--
-- Name: benutzer trg_benutzer_aktualisiert_am; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_benutzer_aktualisiert_am BEFORE UPDATE ON public.benutzer FOR EACH ROW EXECUTE FUNCTION public.set_aktualisiert_am();


--
-- Name: buecher_exemplare trg_buecher_exemplare_aktualisiert_am; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_buecher_exemplare_aktualisiert_am BEFORE UPDATE ON public.buecher_exemplare FOR EACH ROW EXECUTE FUNCTION public.set_aktualisiert_am();


--
-- Name: buecher_titel trg_buecher_titel_aktualisiert_am; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_buecher_titel_aktualisiert_am BEFORE UPDATE ON public.buecher_titel FOR EACH ROW EXECUTE FUNCTION public.set_aktualisiert_am();


--
-- Name: schadensfaelle trg_schadensfaelle_aktualisiert_am; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_schadensfaelle_aktualisiert_am BEFORE UPDATE ON public.schadensfaelle FOR EACH ROW EXECUTE FUNCTION public.set_aktualisiert_am();


--
-- Name: schueler trg_schueler_aktualisiert_am; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_schueler_aktualisiert_am BEFORE UPDATE ON public.schueler FOR EACH ROW EXECUTE FUNCTION public.set_aktualisiert_am();


--
-- Name: audit_log audit_log_bearbeiter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_bearbeiter_id_fkey FOREIGN KEY (bearbeiter_id) REFERENCES public.benutzer(id) ON DELETE SET NULL;


--
-- Name: ausleihen ausleihen_ausleiher_benutzer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ausleihen
    ADD CONSTRAINT ausleihen_ausleiher_benutzer_id_fkey FOREIGN KEY (ausleiher_benutzer_id) REFERENCES public.benutzer(id) ON DELETE SET NULL;


--
-- Name: ausleihen ausleihen_bearbeiter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ausleihen
    ADD CONSTRAINT ausleihen_bearbeiter_id_fkey FOREIGN KEY (bearbeiter_id) REFERENCES public.benutzer(id) ON DELETE SET NULL;


--
-- Name: ausleihen ausleihen_exemplar_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ausleihen
    ADD CONSTRAINT ausleihen_exemplar_id_fkey FOREIGN KEY (exemplar_id) REFERENCES public.buecher_exemplare(id) ON DELETE RESTRICT;


--
-- Name: ausleihen ausleihen_rueckgabe_bearbeiter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ausleihen
    ADD CONSTRAINT ausleihen_rueckgabe_bearbeiter_id_fkey FOREIGN KEY (rueckgabe_bearbeiter_id) REFERENCES public.benutzer(id) ON DELETE SET NULL;


--
-- Name: ausleihen ausleihen_schueler_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ausleihen
    ADD CONSTRAINT ausleihen_schueler_id_fkey FOREIGN KEY (schueler_id) REFERENCES public.schueler(id) ON DELETE RESTRICT;


--
-- Name: benutzer_rollen benutzer_rollen_benutzer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.benutzer_rollen
    ADD CONSTRAINT benutzer_rollen_benutzer_id_fkey FOREIGN KEY (benutzer_id) REFERENCES public.benutzer(id) ON DELETE CASCADE;


--
-- Name: buecher_exemplare buecher_exemplare_titel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.buecher_exemplare
    ADD CONSTRAINT buecher_exemplare_titel_id_fkey FOREIGN KEY (titel_id) REFERENCES public.buecher_titel(id) ON DELETE CASCADE;


--
-- Name: class_books class_books_book_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_books
    ADD CONSTRAINT class_books_book_id_fkey FOREIGN KEY (book_id) REFERENCES public.buecher_titel(id) ON DELETE CASCADE;


--
-- Name: klassensatz_reservierungen klassensatz_reservierungen_angefordert_von_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.klassensatz_reservierungen
    ADD CONSTRAINT klassensatz_reservierungen_angefordert_von_fkey FOREIGN KEY (angefordert_von) REFERENCES public.benutzer(id) ON DELETE SET NULL;


--
-- Name: klassensatz_reservierungen klassensatz_reservierungen_titel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.klassensatz_reservierungen
    ADD CONSTRAINT klassensatz_reservierungen_titel_id_fkey FOREIGN KEY (titel_id) REFERENCES public.buecher_titel(id) ON DELETE CASCADE;


--
-- Name: schadensfaelle schadensfaelle_ausleihe_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schadensfaelle
    ADD CONSTRAINT schadensfaelle_ausleihe_id_fkey FOREIGN KEY (ausleihe_id) REFERENCES public.ausleihen(id) ON DELETE SET NULL;


--
-- Name: schadensfaelle schadensfaelle_benutzer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schadensfaelle
    ADD CONSTRAINT schadensfaelle_benutzer_id_fkey FOREIGN KEY (benutzer_id) REFERENCES public.benutzer(id) ON DELETE SET NULL;


--
-- Name: schadensfaelle schadensfaelle_exemplar_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schadensfaelle
    ADD CONSTRAINT schadensfaelle_exemplar_id_fkey FOREIGN KEY (exemplar_id) REFERENCES public.buecher_exemplare(id) ON DELETE RESTRICT;


--
-- Name: schadensfaelle schadensfaelle_schueler_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schadensfaelle
    ADD CONSTRAINT schadensfaelle_schueler_id_fkey FOREIGN KEY (schueler_id) REFERENCES public.schueler(id) ON DELETE RESTRICT;


--
-- Name: schadensfaelle schadensfaelle_storniert_von_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.schadensfaelle
    ADD CONSTRAINT schadensfaelle_storniert_von_fkey FOREIGN KEY (storniert_von) REFERENCES public.benutzer(id) ON DELETE SET NULL;


--
-- Name: vormerkungen vormerkungen_schueler_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vormerkungen
    ADD CONSTRAINT vormerkungen_schueler_id_fkey FOREIGN KEY (schueler_id) REFERENCES public.schueler(id) ON DELETE SET NULL;


--
-- Name: vormerkungen vormerkungen_titel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vormerkungen
    ADD CONSTRAINT vormerkungen_titel_id_fkey FOREIGN KEY (titel_id) REFERENCES public.buecher_titel(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Q2H99zOmWBFKsh19AMuwiph4ehEhGrmXkAYTG3c2z7t5ea9fGgPqZ75ZbgRcT6o

